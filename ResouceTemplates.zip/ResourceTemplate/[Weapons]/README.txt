1. Place all custom gun files into the "stream"
2. DONT TOUCH THE RESOURCE.LUA!!!!!!

-Aidan