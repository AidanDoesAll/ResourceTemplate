1. Place the folders into your resource folder 
2. Place the folling into your server.cfg

start [CivCars]
start [EmergencyVehicles]
start [Pack1]
start [Pack2]
start [VIP]
start [Weapons]
start customguns

---PersonInfo---
-Author Aidan
-Discord:https://discord.gg/CYrxKYkwVd
-Version 1.0.0

---SideNote---
*These can be changed and deleted for you liking*
-You can NOT touch anything that is a resource.lua